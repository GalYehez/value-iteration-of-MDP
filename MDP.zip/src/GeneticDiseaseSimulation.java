import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class GeneticDiseaseSimulation {

    private static final double CARRIER_PROBABILITY = 0.01; // Probability for initial generation to be carriers
    private static final Random random = new Random();
    private static final Map<String, Integer> carrierCounts = new HashMap<>();
    private static final int[] SAMPLE_SIZES = {1000, 10000, 100000}; // The three sample sizes to simulate
    private static final double NON_CARRIER_PROBABILITY = 0.99;


    public static void main(String[] args) {
        int[] sampleSizes = {1000, 10000, 100000};
        for (int sampleSize : sampleSizes) {
            simulate(sampleSize);
        }
        
        for (int sampleSize : SAMPLE_SIZES) {
        	GeneticDiseaseImportanceSampling.performImportanceSampling(sampleSize);
        }
        
        
        double totalLouisSick = 0;
        Map<String, Double> carrierIfLouisSick = new HashMap<>();
        initializeMap(carrierIfLouisSick);

        // Enumerate all possible combinations for the initial generation
        for (double alice : new double[]{NON_CARRIER_PROBABILITY, CARRIER_PROBABILITY}) {
            for (double bob : new double[]{NON_CARRIER_PROBABILITY, CARRIER_PROBABILITY}) {
                for (double cindy : new double[]{NON_CARRIER_PROBABILITY, CARRIER_PROBABILITY}) {
                    for (double dave : new double[]{NON_CARRIER_PROBABILITY, CARRIER_PROBABILITY}) {
                        for (double ellen : new double[]{NON_CARRIER_PROBABILITY, CARRIER_PROBABILITY}) {
                            // Calculate the generations
                            double fred = combine(alice, bob);
                            double gwen = combine(cindy, bob);
                            double henry = combine(cindy, dave);
                            double iona = combine(ellen, bob);
                            double john = combine(fred, gwen);
                            double katherine = combine(henry, iona);
                            double louisSick = (john == CARRIER_PROBABILITY && katherine == CARRIER_PROBABILITY) ? 1.0 : 0.0;
                            
                            if (louisSick > 0) {
                                totalLouisSick += louisSick;
                                carrierIfLouisSick.put("Alice", carrierIfLouisSick.get("Alice") + (alice == CARRIER_PROBABILITY ? louisSick : 0));
                                carrierIfLouisSick.put("Bob", carrierIfLouisSick.get("Bob") + (bob == CARRIER_PROBABILITY ? louisSick : 0));
                                carrierIfLouisSick.put("Cindy", carrierIfLouisSick.get("Cindy") + (cindy == CARRIER_PROBABILITY ? louisSick : 0));
                                carrierIfLouisSick.put("Dave", carrierIfLouisSick.get("Dave") + (dave == CARRIER_PROBABILITY ? louisSick : 0));
                                carrierIfLouisSick.put("Ellen", carrierIfLouisSick.get("Ellen") + (ellen == CARRIER_PROBABILITY ? louisSick : 0));
                                carrierIfLouisSick.put("Fred", carrierIfLouisSick.get("Fred") + (fred == CARRIER_PROBABILITY ? louisSick : 0));
                                carrierIfLouisSick.put("Gwen", carrierIfLouisSick.get("Gwen") + (gwen == CARRIER_PROBABILITY ? louisSick : 0));
                                carrierIfLouisSick.put("Henry", carrierIfLouisSick.get("Henry") + (henry == CARRIER_PROBABILITY ? louisSick : 0));
                                carrierIfLouisSick.put("Iona", carrierIfLouisSick.get("Iona") + (iona == CARRIER_PROBABILITY ? louisSick : 0));
                                carrierIfLouisSick.put("John", carrierIfLouisSick.get("John") + (john == CARRIER_PROBABILITY ? louisSick : 0));
                                carrierIfLouisSick.put("Katherine", carrierIfLouisSick.get("Katherine") + (katherine == CARRIER_PROBABILITY ? louisSick : 0));
                            }
                        }
                    }
                }
            }
        }

        for (String mouse : carrierIfLouisSick.keySet()) {
            double probability = carrierIfLouisSick.get(mouse) / totalLouisSick;
            System.out.println(mouse + " carrier probability given Louis is sick: " + probability);
        }
        
        
        
        
        
    }
    
    
    private static void initializeMap(Map<String, Double> map) {
        map.put("Alice", 0.0);
        map.put("Bob", 0.0);
        map.put("Cindy", 0.0);
        map.put("Dave", 0.0);
        map.put("Ellen", 0.0);
        map.put("Fred", 0.0);
        map.put("Gwen", 0.0);
        map.put("Henry", 0.0);
        map.put("Iona", 0.0);
        map.put("John", 0.0);
        map.put("Katherine", 0.0);
    }

    private static double combine(double probParent1, double probParent2) {
        return probParent1 == CARRIER_PROBABILITY || probParent2 == CARRIER_PROBABILITY ? CARRIER_PROBABILITY : NON_CARRIER_PROBABILITY;
    }

    private static void simulate(int sampleSize) {
        initializeCarrierCounts();
        int louisSickCount = performSampling(sampleSize);
        printResults(louisSickCount, sampleSize);
    }

    private static void initializeCarrierCounts() {
        String[] mice = {"Alice", "Bob", "Cindy", "Dave", "Ellen", 
                         "Fred", "Gwen", "Henry", "Iona", "John", "Katherine", "Louis"};
        for (String mouse : mice) {
            carrierCounts.put(mouse, 0);
        }
    }

    private static int performSampling(int sampleSize) {
        int louisSickCount = 0;

        for (int i = 0; i < sampleSize; i++) {
            boolean isLouisSick = random.nextDouble() < CARRIER_PROBABILITY;
            if (isLouisSick) {
                louisSickCount++;
                for (String mouse : carrierCounts.keySet()) {
                    if (random.nextDouble() < CARRIER_PROBABILITY) {
                        carrierCounts.put(mouse, carrierCounts.get(mouse) + 1);
                    }
                }
            }
        }

        return louisSickCount;
    }

    private static void printResults(int louisSickCount, int sampleSize) {
        System.out.println("For " + sampleSize + " samples:");
        System.out.println("Percentage of samples where Louis is sick: " +
                           (double) louisSickCount / sampleSize * 100 + "%");

        System.out.println("Rejection Sampling results:");
        for (String mouse : carrierCounts.keySet()) {
            double probability = (double) carrierCounts.get(mouse) / louisSickCount;
            System.out.println(mouse + " carrier probability: " + probability);
        }
        System.out.println();
    }
}