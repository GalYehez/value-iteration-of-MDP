import java.util.Random;

public class Mouse {
    String name;
    String genotype; // "pp", "pd", or "dd"
    Mouse parent1, parent2;

    // Constructor for initial generation with known genotype
    public Mouse(String name, String genotype) {
        this.name = name;
        this.genotype = genotype;
    }
    
    public boolean isSick() {
        return this.genotype.equals("dd");
    }
    
    public boolean isCarrier() {
        return this.genotype.equals("pd");
    }
    
    // Constructor
    public Mouse(String name, Mouse parent1, Mouse parent2) {
        this.name = name;
        this.parent1 = parent1;
        this.parent2 = parent2;
    }

	// Method to determine and set the mouse's genotype based on its parents
    public void determineGenotype() {
        if (parent1 == null || parent2 == null || parent1.genotype.isEmpty() || parent2.genotype.isEmpty()) {
            return;
        }

        // Assuming equal chance of inheriting each allele from each parent. Randomly 0 or 1
        int alleleIndexFromParent1 = (int) (Math.random() * 2);
        int alleleIndexFromParent2 = (int) (Math.random() * 2);

        char alleleFromParent1 = parent1.genotype.charAt(alleleIndexFromParent1);
        char alleleFromParent2 = parent2.genotype.charAt(alleleIndexFromParent2);

        this.genotype = "" + alleleFromParent1 + alleleFromParent2;

        // Ensure genotype is either "pp", "pd", or "dd"
        if (this.genotype.equals("dp")) {
            this.genotype = "pd";
        }
    }
}
