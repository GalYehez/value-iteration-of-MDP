import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class GeneticDiseaseImportanceSampling {

    private static final Random random = new Random();
    private static final double CARRIER_PROBABILITY = 0.01; // Simplified probability for a mouse to be a carrier


    public static void performImportanceSampling(int sampleSize) {
        Map<String, Double> weightedCarrierCounts = new HashMap<>();
        double totalWeight = 0.0; // Total weight for normalization

        String[] mice = new String[]{"Alice", "Bob", "Cindy", "Dave", "Ellen", "Fred", "Gwen", "Henry", "Iona", "John", "Katherine", "Louis"};
        for (String mouse : mice) {
            weightedCarrierCounts.put(mouse, 0.0);
        }

        for (int i = 0; i < sampleSize; i++) {
            // Simulate the genotypes for each mouse, assuming a higher chance of being a carrier to make Louis being sick more probable
            Map<String, Boolean> genotypes = simulateGenotypes();

            double weight = calculateSampleWeight(genotypes);

            // Update weighted counts for carriers
            for (String mouse : genotypes.keySet()) {
                if (genotypes.get(mouse)) {
                    double currentWeight = weightedCarrierCounts.get(mouse);
                    weightedCarrierCounts.put(mouse, currentWeight + weight);
                }
            }
            totalWeight += weight;
        }

        // Normalize weighted counts and print results
        System.out.println("Importance Sampling results for " + sampleSize + " samples:");
        for (String mouse : weightedCarrierCounts.keySet()) {
            double normalizedProbability = weightedCarrierCounts.get(mouse) / totalWeight;
            System.out.println(mouse + " carrier probability: " + normalizedProbability);
        }
        System.out.println();
    }

    private static Map<String, Boolean> simulateGenotypes() {
        Map<String, Boolean> genotypes = new HashMap<>();
        for (String mouse : new String[]{"Alice", "Bob", "Cindy", "Dave", "Ellen", "Fred", "Gwen", "Henry", "Iona", "John", "Katherine", "Louis"}) {
            genotypes.put(mouse, random.nextDouble() < CARRIER_PROBABILITY);
        }
        return genotypes;
    }

    private static double calculateSampleWeight(Map<String, Boolean> genotypes) {
        return genotypes.get("Louis") ? 1.0 : 0.0; // Assign weight 1 if Louis is a carrier, otherwise 0
    }
}